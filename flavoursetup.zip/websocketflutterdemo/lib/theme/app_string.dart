/// define all the Strings here which we have to localize
class AppString {
  static const String appName = "Edit profile pic";
  static const String takeAPic = "Take a Picture";
  static const String chooseFromGallery = "Choose from Gallery";
  static const String removePicture = "Remove Picture";
  static const String cancel = "Cancel";

}
