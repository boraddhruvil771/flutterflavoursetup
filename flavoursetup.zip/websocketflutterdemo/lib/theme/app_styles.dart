import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:editprofilepic/theme/app_colors.dart';
import 'package:editprofilepic/theme/dimens.dart';


abstract class AppStyles {
  // Poppins Fonts
  static const TextStyle _textStyle =
      TextStyle(color: Colors.purple, fontFamily: 'Poppins');

  static final TextStyle regularStyle = _textStyle.copyWith(
    fontWeight: FontWeight.w400,
  );
  static final TextStyle lightStyle = _textStyle.copyWith(
    fontWeight: FontWeight.w300,
  );

  static final TextStyle mediumStyle = _textStyle.copyWith(
    fontWeight: FontWeight.w500,
  );

  static final TextStyle semiBoldStyle = _textStyle.copyWith(
    fontWeight: FontWeight.w600,
  );

  static final TextStyle boldStyle = _textStyle.copyWith(
    fontWeight: FontWeight.w700,
  );

  static final TextStyle button =
      mediumStyle.copyWith(color: AppColors.whiteColor);

  static final TextStyle textExtraLarge = semiBoldStyle.copyWith(
    fontSize: Dimens.fontSize22,
  );
  static final TextStyle textMediumExtraLarge = mediumStyle.copyWith(
    fontSize: Dimens.fontSize20,
  );
  static final TextStyle textLarge = semiBoldStyle.copyWith(
    fontSize: Dimens.fontSize18,
  );
  static final TextStyle textMediumLarge = mediumStyle.copyWith(
    fontSize: Dimens.fontSize18,
  );

  static final TextStyle textMediumGreen = mediumStyle.copyWith(
      fontSize: Dimens.fontSize18, color: AppColors.darkGreenColor);

  static final TextStyle textMedium = mediumStyle.copyWith(
    fontSize: Dimens.fontSize16,
  );
  static final TextStyle textRegularMedium = regularStyle.copyWith(
    fontSize: Dimens.fontSize16,
  );
  static final TextStyle textRegularExtraMedium = semiBoldStyle.copyWith(
    fontSize: Dimens.fontSize15,
  );
  static final TextStyle textRegularLight = regularStyle.copyWith(
    fontSize: Dimens.fontSize15,
  );
  static final TextStyle textRegular = mediumStyle.copyWith(
    fontSize: Dimens.fontSize14,
  );
  static final TextStyle textRegularGreen = mediumStyle.copyWith(
      fontSize: Dimens.fontSize15, color: AppColors.darkGreenColor);

  static final TextStyle textRegularExtraLight = regularStyle.copyWith(
    fontSize: Dimens.fontSize14,
  );

  static final TextStyle textRegularThinLight = regularStyle.copyWith(
    fontSize: Dimens.fontSize13,
  );

  static final TextStyle textSmall = regularStyle.copyWith(
    fontSize: Dimens.fontSize13,
  );
  static final TextStyle textExtraSmall = regularStyle.copyWith(
    fontSize: Dimens.fontSize10,
  );
}
