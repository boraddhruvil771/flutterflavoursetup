import 'dart:io';

import 'package:device_info_plus/device_info_plus.dart';
import 'package:editprofilepic/theme/app_styles.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';

import '../theme/custom_text_label.dart';

/// bottom sheet with 4 button for select image from gallery and camera
showABottomSheetForSelectimage({required BuildContext context, String? labelFirst, String? labelSecond, String? labelThird, bool? visiblity, String? cancelButtonText, Function()? onFirstLabelTap, Function()? onSecondLabelTap, Function()? onThirdLabelTap, Function()? onFourthLableTap}) {
  showCupertinoModalPopup(
    context: context,
    barrierDismissible: false,
    builder: (BuildContext context) => Padding(
      padding: const EdgeInsets.only(
        left: 16,
        right: 16,
        bottom: 16,
      ),
      child: CupertinoActionSheet(
        actions: [
          Container(
            color: Colors.white, // Set background color to white
            child: CupertinoActionSheetAction(
              onPressed: () {
                onFirstLabelTap?.call();
                // goBack();
                // Handle action 1
              },
              child: CustomTextLabel(
                label: labelFirst ?? "",
                style: AppStyles.textMedium.copyWith(fontSize: 16, color: Colors.purple),
              ),
            ),
          ),
          Container(
            color: Colors.white, // Set background color to white
            child: CupertinoActionSheetAction(
              onPressed: () {
                onSecondLabelTap?.call();
                // goBack();
                // Handle action 2
              },
              child: CustomTextLabel(
                label: labelSecond ?? "",
                style: AppStyles.textMedium.copyWith(fontSize: 16, color: Colors.purple),
              ),
            ),
          ),
          Visibility(
            visible: visiblity == true,
            child: Container(
              color: Colors.white, // Set background color to white
              child: CupertinoActionSheetAction(
                onPressed: () {
                  onThirdLabelTap?.call();
                  // Handle action 2
                },
                child: CustomTextLabel(
                  label: labelThird ?? "",
                  style: AppStyles.textMedium.copyWith(fontSize: 16, color: Colors.purple),
                ),
              ),
            ),
          ),
        ],
        cancelButton: CupertinoActionSheetAction(
          onPressed: () {
            onFourthLableTap?.call();
          },
          child: CustomTextLabel(
            label: cancelButtonText ?? "",
            style: AppStyles.textMedium.copyWith(fontSize: 16, color: Colors.purple),
          ),
        ),
      ),
    ),
  );
}

/// Crop selected image from camera or gallery
Future<CroppedFile?> cropImage(XFile imageFile) async {
  CroppedFile? croppedFile = await ImageCropper().cropImage(
    sourcePath: imageFile.path,
    compressQuality: 70,
    maxHeight: 80,
    maxWidth: 80,
    compressFormat: ImageCompressFormat.jpg,
    cropStyle: CropStyle.rectangle,
    uiSettings: [
      AndroidUiSettings(toolbarTitle: 'Crop', cropGridColor: Colors.black, initAspectRatio: CropAspectRatioPreset.original, lockAspectRatio: false, hideBottomControls: true),
      IOSUiSettings(
        minimumAspectRatio: 1.0,
      ),
    ],
    aspectRatioPresets: [CropAspectRatioPreset.square, CropAspectRatioPreset.ratio3x2, CropAspectRatioPreset.original, CropAspectRatioPreset.ratio4x3, CropAspectRatioPreset.ratio16x9],
  );
  return croppedFile;
}

/// check permission for camera and photo access.
void checkPermission(BuildContext context, Function isGrantedCallBack) async {
  FocusScope.of(context).requestFocus(FocusNode());
  Map<Permission, PermissionStatus> statues = await [Permission.camera, Permission.storage, Permission.photos].request();
  PermissionStatus? statusCamera = statues[Permission.camera];
  PermissionStatus? statusStorage;
  PermissionStatus? statusPhoto;
  if (Platform.isAndroid) {
    statusStorage = statues[Permission.storage];
    var deviceInfo = DeviceInfoPlugin();
    AndroidDeviceInfo info = await deviceInfo.androidInfo;
    if (info.version.sdkInt > 32) {
      statusStorage = statues[Permission.photos];
    } else {
      statusStorage = statues[Permission.storage];
    }
  } else if (Platform.isIOS) {
    statusPhoto = statues[Permission.photos];
  }

  bool isGranted = statusCamera == PermissionStatus.granted && (statusPhoto == PermissionStatus.granted || (Platform.isAndroid && statusStorage == PermissionStatus.granted));
  print('object ${isGranted}');
  if (isGranted) {
    isGrantedCallBack.call();
  }
  bool isPermanentlyDenied = statusCamera == PermissionStatus.permanentlyDenied || (Platform.isAndroid && statusStorage == PermissionStatus.permanentlyDenied) || (Platform.isIOS && statusPhoto == PermissionStatus.permanentlyDenied);
  if (isPermanentlyDenied) {
    openAppSettings();
  }
}
/* void checkServiceStatus(BuildContext context, PermissionWithService permission) async {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text((await permission.serviceStatus).toString()),
    ));
  }

  Future<void> requestPermission(Permission permission) async {
    final status = await permission.request();

    if (await permission.isDenied) {
      await permission.request();
    }
    setState(() {
      print(status);
      _permissionStatus = status;
      print(_permissionStatus);
    });
  }
*/
